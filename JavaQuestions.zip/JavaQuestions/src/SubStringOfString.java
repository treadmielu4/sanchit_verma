
public class SubStringOfString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "I love my India. India ia a beautiful country.";

	        String new_str = str.substring(2,15);

	        System.out.println("old = " + str);
	        System.out.println("new = " + new_str);
	}

}
